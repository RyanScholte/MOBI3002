package com.example.m07_sensors;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Formatter;

public class BouncingBallView extends View implements SensorEventListener {

    private ArrayList<Ball> balls = new ArrayList<>(); // list of Balls
    private Ball ball_1;  // use this to reference the first ball in the arraylist
    private Box box;

    private StringBuilder statusMsg = new StringBuilder();
    private Formatter formatter = new Formatter(statusMsg);
    private Paint paint;

    private int string_line = 1;
    private int string_x = 10;
    private int string_line_size = 40;
    private ArrayList<String> debug_dump1 = new ArrayList<>();
    private String[] debug_dump2 = new String[200];

    private float previousX;
    private float previousY;

    private double ax = 0;
    private double ay = 0;
    private double az = 0;

    private Square movingSquare;
    private ArrayList<Triangle> triangles = new ArrayList<>();  // List to store spinning triangles

    public BouncingBallView(Context context) {
        super(context);

        for (int i = 1; i < 200; i++) {
            debug_dump2[i] = "  ";
        }

        box = new Box(Color.BLACK);

        balls.add(new Ball(Color.GREEN));
        ball_1 = balls.get(0);
        Log.w("BouncingBallLog", "Just added a bouncing ball");

        balls.add(new Ball(Color.CYAN));
        Log.w("BouncingBallLog", "Just added another bouncing ball");

        paint = new Paint();
        paint.setTypeface(Typeface.MONOSPACE);
        paint.setTextSize(32);
        paint.setColor(Color.CYAN);

        this.setFocusable(true);
        this.requestFocus();
        this.setFocusableInTouchMode(true);

        movingSquare = new Square(Color.MAGENTA, 200, 200, 5, 5);

        // Initialize with one spinning triangle
        triangles.add(new Triangle(Color.BLUE, 400, 400));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        box.draw(canvas);

        for (Ball b : balls) {
            b.draw(canvas);
            b.moveWithCollisionDetection(box);
        }

        movingSquare.draw(canvas);
        movingSquare.moveWithCollisionDetection(box);

        // Draw all spinning triangles
        for (Triangle triangle : triangles) {
            triangle.draw(canvas);
            triangle.update();
        }

        if (string_line * string_line_size > box.yMax) {
            string_line = 1;
            debug_dump1.clear();
        } else {
            string_line++;
        }

        if (string_x > box.xMax) {
            string_x = 10;
        } else {
            string_x++;
        }

        debug_dump2[string_line] = "Acc(" + ax + ", " + ay + " ," + az + ")";
        for (int i = 1; i < debug_dump2.length; i++) {
            // un-comment to print debug code on screen
            //canvas.drawText(debug_dump2[i], string_x, i * string_line_size, paint);
        }

        this.invalidate();
    }

    @Override
    public void onSizeChanged(int w, int h, int oldW, int oldH) {
        box.set(0, 0, w, h);
        Log.w("BouncingBallLog", "onSizeChanged w=" + w + " h=" + h);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float currentX = event.getX();
        float currentY = event.getY();
        float deltaX, deltaY;
        float scalingFactor = 5.0f / ((box.xMax > box.yMax) ? box.yMax : box.xMax);
        float slow_down_speed_factor = 10.0f;
        switch (event.getAction()) {
            case MotionEvent.ACTION_MOVE:
                deltaX = (currentX - previousX) / slow_down_speed_factor;
                deltaY = (currentY - previousY) / slow_down_speed_factor;
                ball_1.speedX += deltaX * scalingFactor;
                ball_1.speedY += deltaY * scalingFactor;
                Log.w("BouncingBallLog", "x,y= " + previousX + " ," + previousY + "  Xdiff=" + deltaX + " Ydiff=" + deltaY);
                balls.add(new Ball(Color.RED, previousX, previousY, deltaX, deltaY));

                if (balls.size() > 20) {
                    balls.clear();
                    balls.add(new Ball(Color.GREEN));
                    ball_1 = balls.get(0);
                }
                break;

            case MotionEvent.ACTION_DOWN:
                // Add a new spinning triangle at the touch location
                triangles.add(new Triangle(Color.BLUE, currentX, currentY));
                break;
        }
        previousX = currentX;
        previousY = currentY;

        return true;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            ax = -event.values[0];
            ay = event.values[1];
            az = event.values[2];

            for (Ball b : balls) {
                b.setAcc(ax, ay, az);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        Log.v("onAccuracyChanged", "event=" + sensor.toString());
    }
}