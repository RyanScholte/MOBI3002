package com.example.m07_sensors;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Square extends Shape {
    private double sideLength = 50; // Square's side length
    private double speedX;      // Square's speed along the x-axis
    private double speedY;      // Square's speed along the y-axis
    private double speedResistance = 0.99; // Amount of slow-down
    private double accResistance = 0.99;   // Amount of slow-down
    private Paint paint;        // The paint style, color used for drawing

    // Constructor
    public Square(int color, double x, double y, double speedX, double speedY) {
        super(x, y,color);
        this.speedX = speedX;
        this.speedY = speedY;

        paint = new Paint();
        paint.setColor(color);
    }

    // Override moveWithCollisionDetection method
    @Override
    public void moveWithCollisionDetection(Box box) {
        // Get new (x, y) position
        x = (x + speedX);
        y = (y + speedY);

        // Add acceleration to speed
        speedX = (speedX) * speedResistance + ax * accResistance;
        speedY = (speedY) * speedResistance + ay * accResistance;

        // Detect collision with walls and react
        if (x + sideLength > box.xMax) {
            speedX = -speedX;
            x = box.xMax - sideLength;
        } else if (x - sideLength < box.xMin) {
            speedX = -speedX;
            x = box.xMin + sideLength;
        }
        if (y + sideLength > box.yMax) {
            speedY = -speedY;
            y = box.yMax - sideLength;
        } else if (y - sideLength < box.yMin) {
            speedY = -speedY;
            y = box.yMin + sideLength;
        }
    }

    // Override draw method
    @Override
    public void draw(Canvas canvas) {
        // Draw the square on the canvas
        canvas.drawRect((float) (x - sideLength), (float) (y - sideLength),
                (float) (x + sideLength), (float) (y + sideLength), paint);
    }

    // Override setAcc method
    @Override
    public void setAcc(double ax, double ay, double az) {
        // Set acceleration
        this.ax = ax;
        this.ay = ay;
        this.az = az;
    }
}