package com.example.m07_sensors;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

public class Triangle extends Shape {

    private Paint paint;  // The paint style, color used for drawing
    private float rotationAngle = 0;
    private float rotationSpeed = 2.0f;  // Adjust as needed

    // Constructor
    public Triangle(int color, double x, double y) {
        super(x, y, color);

        paint = new Paint();
        paint.setColor(color);
    }

    @Override
    public void moveWithCollisionDetection(Box box) {
        // Triangle is stationary, no movement needed
    }

    @Override
    public void draw(Canvas canvas) {
        // Draw the triangle on the canvas
        Path path = new Path();
        path.moveTo((float) x, (float) y - 50);  // Top
        path.lineTo((float) x - 50, (float) y + 50);  // Bottom-left
        path.lineTo((float) x + 50, (float) y + 50);  // Bottom-right
        path.close();

        canvas.save();
        canvas.rotate(rotationAngle, (float) x, (float) y);
        canvas.drawPath(path, paint);
        canvas.restore();
    }

    @Override
    public void setAcc(double ax, double ay, double az) {
        // Triangle does not react to acceleration
    }

    public void update() {
        // Spin the triangle
        rotationAngle += rotationSpeed;
        if (rotationAngle >= 360) {
            rotationAngle = 0;
        }
    }
}