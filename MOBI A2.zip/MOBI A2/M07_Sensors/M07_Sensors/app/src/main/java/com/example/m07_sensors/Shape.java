package com.example.m07_sensors;

import android.graphics.Canvas;
import android.graphics.Paint;

// Abstract base class for shapes
public abstract class Shape {
    protected double x; // x position
    protected double y; // y position
    protected double ax; // Acceleration in the x direction
    protected double ay; // Acceleration in the y direction
    protected double az; // Acceleration in the z direction
    protected int color; // Color of the shape

    // Add this constructor to the Shape class
    public Shape(double x, double y, int color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }

    // Abstract method for moving the shape with collision detection
    public abstract void moveWithCollisionDetection(Box box);

    // Abstract method for drawing the shape on the canvas
    public abstract void draw(Canvas canvas);

    // Abstract method for setting acceleration
    public abstract void setAcc(double ax, double ay, double az);

    // Method to set the color of the shape
    public void setColor(int color) {
        this.color = color;
    }

    // Method to get the x position of the shape
    public double getX() {
        return x;
    }

    // Method to get the y position of the shape
    public double getY() {
        return y;
    }
    public int getColor() {
        return color;
    }

}
